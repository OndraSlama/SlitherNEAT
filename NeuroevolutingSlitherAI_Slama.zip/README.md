SlitherAI
start by running main.py

just pygame needed (console: python -m pip install -U pygame --user)